from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import numpy as np
import torch
import model
device = torch.device('cpu')
df_movies = pd.read_csv('./data/movies.csv')
df_seemovies = pd.read_csv('./data/movies100.csv')
df_ratings = pd.read_csv('./data/rating.csv')
user_ids_tensor = torch.tensor(df_ratings['user_id'].values, dtype=torch.long)
movie_ids_tensor = torch.tensor(df_ratings['movie_id'].values, dtype=torch.long)
n_users = len(df_ratings['user_id'].unique())
n_movies = len(df_ratings['movie_id'].unique())

movie_id = None
user_id = None
tags = []
app = Flask(__name__)
def predict_relevant_scores(model, user_id, movie_ids): # one user - all movies
    
    user_ids = torch.tensor([user_id] * len(movie_ids), dtype=torch.long)
    movie_ids = torch.tensor(movie_ids, dtype=torch.long)
    
    with torch.no_grad():
        user_ids = user_ids.to(device)
        movie_ids = movie_ids.to(device)
        outputs = model(user_ids, movie_ids)
        
    return outputs
def recommend(model, user_id, n_movies=10, include_watched=True):
    
    rel_scores = predict_relevant_scores(model, user_id, list(range(0, 943)))
    desc_rel_scores = rel_scores.sort(descending=True)
    
    recommended_movies = []
    counts = 0
    for i, idx in enumerate(desc_rel_scores[1]):
        if not df_seemovies[(df_seemovies['movie_id'] == int(idx))].empty:
            # Kiểm tra xem bộ phim đã được đánh giá bởi người dùng chưa
            original_rating = df_ratings[(df_ratings['user_id'] == user_id) & (df_ratings['movie_id'] == int(idx))]
            if len(original_rating) > 0:
                original_rating = original_rating['rating'].iloc[0]
                if not include_watched:
                    continue
            else:    
                original_rating = float('nan')
            
            # Thêm bộ phim vào danh sách đề xuất
            recommended_movies.append((int(idx), df_movies['title'].iloc[int(idx)], original_rating, desc_rel_scores[0][i].item()))
            counts += 1
        
        # Kiểm tra nếu đã đạt đủ số lượng bộ phim đề xuất
        if counts == n_movies:
            return recommended_movies
    
    return recommended_movies
ex_user_id = 66
include_watched = True

n_users = 943  # Số lượng người dùng đúng từ dữ liệu gốc
n_movies = 1682  # Số lượng phim đúng từ dữ liệu gốc
embedding_dim = 8
num_hiddens = 3
hidden_dims = [0] * num_hiddens
for i in range(num_hiddens):
    hidden_dims[i] = embedding_dim * (2 ** (num_hiddens - i - 1))
dropout = 0.5

recommender = model.MovieRecommender(n_users, n_movies, embedding_dim, hidden_dims, dropout)

checkpoint = torch.load("./model/movie-recommender-13.pth", map_location=torch.device('cpu'))
model_state_dict = checkpoint['model_state_dict']
recommender.load_state_dict(model_state_dict)
recommended_movies = recommend(recommender, ex_user_id, 10, include_watched)
print(f'=' * 16)
print(f'User ID: {ex_user_id}')
print(f'=' * 16)

print(pd.DataFrame(recommended_movies, columns=['movie_id', 'title', 'rating', 'relevant_score']))
# Đọc dữ liệu phim

def recommend_movies_by_tags(selected_genres):
    filtered_movies = df_seemovies[df_seemovies['genres'].apply(lambda x: any(tag.lower() in x.lower() for tag in selected_genres))]

    if filtered_movies.empty:
        return []

    movie_ids = filtered_movies['movieId'].values
    average_ratings = []
    for movie_id in movie_ids:
        ratings_for_movie = df_ratings[df_ratings['movieId'] == movie_id]['rating'].values
        if len(ratings_for_movie) > 0:
            average_rating = np.mean(ratings_for_movie)
        else:
            average_rating = 0.0
        average_ratings.append(average_rating)

    filtered_movies['average_rating'] = average_ratings
    recommended_movies = filtered_movies.sort_values(by='average_rating', ascending=False).head(10)

    recommended_movies_data = [
        {"movieId": movie_id, "image": f"../static/images/image/{movie_id}.jpg"}
        for movie_id in recommended_movies['movie_id']
    ]

    return recommended_movies_data

def get_recommended_movies(user_id):
    ex_user_id = user_id
    include_watched = True

    n_users = 943  # Số lượng người dùng đúng từ dữ liệu gốc
    n_movies = 1682  # Số lượng phim đúng từ dữ liệu gốc
    embedding_dim = 8
    num_hiddens = 3
    hidden_dims = [0] * num_hiddens
    for i in range(num_hiddens):
        hidden_dims[i] = embedding_dim * (2 ** (num_hiddens - i - 1))
    dropout = 0.5

    recommender = model.MovieRecommender(n_users, n_movies, embedding_dim, hidden_dims, dropout)

    checkpoint = torch.load("./model/movie-recommender-13.pth", map_location=torch.device('cpu'))
    model_state_dict = checkpoint['model_state_dict']
    recommender.load_state_dict(model_state_dict)
    recommended_movies = recommend(recommender, ex_user_id, 10, include_watched)

    
    recommended_movies_df = pd.DataFrame(recommended_movies, columns=['movie_id', 'title', 'rating', 'relevant_score']).iloc[0]
    recommended_movies_data = []
    for movie_info in recommended_movies[:10]:  # Limit to 10 movies
        movie_id = movie_info[0]  # Assuming movie_id is the first element in tuple (int(idx), ...)
        relevant_score = movie_info[3]  # Assuming relevant_score is the fourth element
        
        # Construct the movie data
        movie_image = f"../static/images/image/{movie_id}.jpg"
        recommended_movies_data.append({
            "movieId": movie_id,
            "image": movie_image
        })

    return recommended_movies_data


def filter_movies_by_tag(tag):
    filtered_movies = df_seemovies[df_seemovies['genres'].str.contains(tag, case=False, na=False)]
    return filtered_movies

drama_movies = filter_movies_by_tag("Drama")
drama_movie_images = [f"../static/images/image/{movie_id}.jpg" for movie_id in drama_movies['movie_id']]
drama_movies_data = [{"movieId": movie_id, "image": image_path} for movie_id, image_path in zip(drama_movies['movie_id'], drama_movie_images)]

comedy_movies = filter_movies_by_tag("Comedy")
comedy_movie_images = [f"../static/images/image/{movie_id}.jpg" for movie_id in comedy_movies['movie_id']]
comedy_movies_data = [{"movieId": movie_id, "image": image_path} for movie_id, image_path in zip(comedy_movies['movie_id'], comedy_movie_images)]

action_movies = filter_movies_by_tag("Action")
action_movie_images = [f"../static/images/image/{movie_id}.jpg" for movie_id in action_movies['movie_id']]
action_movies_data = [{"movieId": movie_id, "image": image_path} for movie_id, image_path in zip(action_movies['movie_id'], action_movie_images)]

thriller_movies = filter_movies_by_tag("Thriller")
thriller_movie_images = [f"../static/images/image/{movie_id}.jpg" for movie_id in thriller_movies['movie_id']]
thriller_movies_data = [{"movieId": movie_id, "image": image_path} for movie_id, image_path in zip(thriller_movies['movie_id'], thriller_movie_images)]

@app.route('/', methods=["GET", "POST"])
def index():
    return render_template('index.html')

@app.route('/old', methods=["GET", "POST"])
def old():
    global user_id
    user_id = int(request.form.get('user_id'))
    if user_id is None:
        return render_template('index.html')
    else:
        return render_template('home.html', recommended_movies_data=get_recommended_movies(user_id), drama_movies_data=drama_movies_data, comedy_movies_data=comedy_movies_data, action_movies_data=action_movies_data, thriller_movies_data=thriller_movies_data)

@app.route('/new', methods=["GET", "POST"])
def new():
    global tags
    tags = request.form.getlist('tags')
    if not tags:
        return render_template('tag.html')
    else:
        return render_template('home.html', recommended_movies_data=recommend_movies_by_tags(tags), drama_movies_data=drama_movies_data, comedy_movies_data=comedy_movies_data, action_movies_data=action_movies_data, thriller_movies_data=thriller_movies_data)

def get_max_user_id():
    return df_ratings.userId.max()

@app.route('/tags')
def tags():
    global user_id
    user_id = int(get_max_user_id() + 1)
    print(user_id)
    return render_template('tag.html')

@app.route('/movie_detail', methods=['GET', 'POST'])
def movie_detail():
    global df_ratings
    global user_id, tags, movie_id
    movie_id = request.form.get('movie_id')
    if not movie_id:
        return render_template('error.html', error_message="No movie selected.")

    movie_details = df_seemovies[df_seemovies['movie_id'] == int(movie_id)].iloc[0]
    rating = df_ratings[(df_ratings['movie_id'] == int(movie_id)) & (df_ratings['user_id'] == user_id)]['rating'].values

    movie_data = {
        'movieId': movie_id,
        'title': movie_details['title'],
        'genres': movie_details['genres'],
        'youtubeId': movie_details['youtubeId'],
        'image': f"../static/images/image/{movie_id}.jpg",
        'rating': rating[0] if rating else None
    }

    if user_id not in df_ratings['user_id'].values:
        return render_template('page-3.html', recommended_movies_data=recommend_movies_by_tags(tags), drama_movies_data=drama_movies_data, comedy_movies_data=comedy_movies_data, action_movies_data=action_movies_data, thriller_movies_data=thriller_movies_data, movie_data=movie_data)
    else:
        return render_template('page-3.html', recommended_movies_data=get_recommended_movies(user_id), drama_movies_data=drama_movies_data, comedy_movies_data=comedy_movies_data, action_movies_data=action_movies_data, thriller_movies_data=thriller_movies_data, movie_data=movie_data)

@app.route('/save_rating', methods=['GET', 'POST'])
def save_rating():
    global df_ratings
    global movie_id, user_id, tags

    new_rating = float(request.form.get('rating'))
    print(new_rating)

    if not movie_id:
        return render_template('error.html', error_message="No movie selected.")
    
    # Kiểm tra xem có dòng nào có cả userId và movieId khớp không
    if not df_ratings[(df_ratings['user_id'] == user_id) & (df_ratings['movie_id'] == int(movie_id))].empty:
        df_ratings.loc[(df_ratings['user_id'] == user_id) & (df_ratings['movie_id'] == int(movie_id)), 'rating'] = new_rating
    else:
        new_entry = pd.DataFrame({'user_id': [user_id], 'movie_id': [int(movie_id)], 'rating': [new_rating]})
        df_ratings = pd.concat([df_ratings, new_entry], ignore_index=True)
        print(new_entry)
    

    movie_details = df_seemovies[df_seemovies['movie_id'] == int(movie_id)].iloc[0]
    rating = df_ratings[(df_ratings['movie_id'] == int(movie_id)) & (df_ratings['user_id'] == user_id)]['rating'].values

    movie_data = {
        'movieId': movie_id,
        'title': movie_details['title'],
        'genres': movie_details['genres'],
        'youtubeId': movie_details['youtubeId'],
        'image': f"../static/images/image/{movie_id}.jpg",
        'rating': rating[0] if rating else None
    }

    if user_id not in df_ratings['user_id'].values:
        return render_template('page-3.html', recommended_movies_data=recommend_movies_by_tags(tags), drama_movies_data=drama_movies_data, comedy_movies_data=comedy_movies_data, action_movies_data=action_movies_data, thriller_movies_data=thriller_movies_data, movie_data=movie_data)
    else:
        return render_template('page-3.html', recommended_movies_data=get_recommended_movies(user_id), drama_movies_data=drama_movies_data, comedy_movies_data=comedy_movies_data, action_movies_data=action_movies_data, thriller_movies_data=thriller_movies_data, movie_data=movie_data)

@app.errorhandler(KeyError)
def handle_key_error(e):
    error_message = f'KeyError: {str(e)}'
    return render_template('error.html', error_message=error_message)

if __name__ == '__main__':
    app.run(debug=True)
