import os
import pandas as pd
import matplotlib.pyplot as plt
import torch
from torch import nn, optim
from torch.nn import functional as F
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import time
import itertools
import random
class MovieRecommender(nn.Module):

    def __init__(self, n_users, n_movies, embedding_dim, hidden_dims, dropout):
        super(MovieRecommender, self).__init__()
        
        self.user_embedding = nn.Embedding(n_users, embedding_dim)
        self.movie_embedding = nn.Embedding(n_movies, embedding_dim)
        
        hidden_layers = []
        in_dim = embedding_dim * 2
        for hid_dim in hidden_dims:
            hidden_layers.append(nn.Linear(in_dim, hid_dim))
            hidden_layers.append(nn.BatchNorm1d(hid_dim))
            hidden_layers.append(nn.ReLU())
            hidden_layers.append(nn.Dropout(p=dropout))
            in_dim = hid_dim
        self.mlp = nn.Sequential(*hidden_layers)
        
        self.out = nn.Linear(embedding_dim + hidden_dims[-1], 1)

    def forward(self, user_id, movie_id):
        
        # Generalized Matrix Factorization
        gmf_u_embed = self.user_embedding(user_id)
        gmf_m_embed = self.movie_embedding(movie_id)
        
        gmf_layer = gmf_u_embed * gmf_m_embed
        
        # Multi-Layer Perception
        mlp_u_embed = self.user_embedding(user_id)
        mlp_m_embed = self.movie_embedding(movie_id)
        
        mlp_inputs = torch.cat((mlp_u_embed, mlp_m_embed), -1)
        mlp_layer = self.mlp(mlp_inputs)
        
        # Neural Matrix Factorization
        neumf_layer = torch.cat((gmf_layer, mlp_layer), -1)
        output = F.sigmoid(self.out(neumf_layer)).squeeze()
        return output
class Checkpoint:
    def __init__(self):
        self.prev_val_loss = float('inf')
        self.better_model = False
        
    def __call__(self, val_loss):
        if val_loss < self.prev_val_loss:
            self.better_model = True
            self.prev_val_loss = val_loss
            
    def save(self, filename, epoch, model, optimizer, train_loss, val_loss, config_params):
        if self.better_model:
            print('Saving checkpoint...')
            try:
                checkpoint = {
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'train_loss': train_loss,
                    'val_loss': val_loss
                }
                checkpoint.update(config_params)
                torch.save(checkpoint, filename)
                print('=> Successfully saved checkpoint!')
                self.better_model = False
            except:
                print('=> Failed to save checkpoint!')
        else:
            print('=> This model state is not better than previous one!')
        
    def load(filename, model, optimizer):
        print('Loading checkpoint...')
        try:
            checkpoint = torch.load(filename)
            model.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            print('=> Successfully loaded checkpoint!')
            checkpoint_info = {
                'epoch': checkpoint['epoch'],
                'train_loss': checkpoint['train_loss'],
                'val_loss': checkpoint['val_loss'],
                'batch_size': checkpoint['batch_size'],
                'dropout': checkpoint['dropout'],
                'embedding_dim': checkpoint['embedding_dim'],
                'learning_rate': checkpoint['learning_rate'],
                'num_hiddens': checkpoint['num_hiddens'],
                'weight_decay': checkpoint['weight_decay']
            }
            return model, optimizer, checkpoint_info
        except:
            print('=> Failed to load checkpoint!')
            return None